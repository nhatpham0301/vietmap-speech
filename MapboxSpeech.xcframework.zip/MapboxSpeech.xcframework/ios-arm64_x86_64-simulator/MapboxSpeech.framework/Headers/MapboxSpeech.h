#import <UIKit/UIKit.h>

//! Project version number for MapboxSpeech.
FOUNDATION_EXPORT double MapboxSpeechVersionNumber;

//! Project version string for MapboxSpeech.
FOUNDATION_EXPORT const unsigned char MapboxSpeechVersionString[];
